<?php
	$servers = array("172.23.138.198");	
?>