<?php
	$n=$_POST['jump'];
	header("Location: quizpage.php?n=".$n);
?>