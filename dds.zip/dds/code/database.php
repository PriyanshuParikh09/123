 <?php
	$db_host = 'phpdatabase.ctwcaoiiyxr0.ap-south-1.rds.amazonaws.com';
	$db_name = 'quiz';
	$db_user = 'admin';
	$db_pass = 'priyanshu';
	$conn = new mysqli($db_host,$db_user,$db_pass,$db_name);
	if($conn->connect_error){
		printf("Connect failed: %s\n",$conn->connect_error);
		exit;
	}
	//echo "Connected successfully";
?>
<!-- <?php
$servername = "phpdatabase.ctwcaoiiyxr0.ap-south-1.rds.amazonaws.com";
$username = "admin";
$password = "priyanshu"; // Replace with your actual password
$dbname = "quiz";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
?> -->

